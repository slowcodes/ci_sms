<nav class="sidebar sidebar-bunker">
                <div class="sidebar-header">
                    <!--<a href="index.html" class="logo"><span>bd</span>task</a>-->
                    <a href="index-2.html" class="logo"><img src="/assets/dist/img/logo.png" alt=""></a>
                </div><!--/.sidebar header-->
                <div class="profile-element d-flex align-items-center flex-shrink-0">
                    <div class="avatar online">
                        <img src="/assets/dist/img/avatar-1.jpg" class="img-fluid rounded-circle" alt="">
                    </div>
                    <div class="profile-text">
                    <h6 class="m-0"><?php echo $first_name.' '.$last_name?></h6>
                        <span><a href="#" class="__cf_email__"><?php echo $username; ?></a></span>
                    </div>
                </div><!--/.profile element-->
                <!--                <form class="search sidebar-form" action="#" method="get" >
                                    <div class="search__inner">
                                        <input type="text" class="search__text" placeholder="Search...">
                                        <i class="typcn typcn-zoom-outline search__helper" data-sa-action="search-close"></i>
                                    </div>
                                </form>/.search-->
                <div class="sidebar-body">
                    <nav class="sidebar-nav">
                        <ul class="metismenu">
                            <li class="nav-label">Main Menu</li>
                            <li class="mm-active">
                                <a class="has-arrow material-ripple" href="#">
                                    <i class="typcn typcn-home-outline mr-2"></i>
                                    Dashboard
                                </a>
                                <ul class="nav-second-level">
                                    <li><a href="/index.php/dashboard/">My Dashboard</a></li>
                                </ul>
                            </li>
                            <li>
                                <a class="has-arrow material-ripple" href="#">
                                    <i class="typcn typcn-chart-pie-outline mr-2"></i>
                                    Members
                                </a>
                                <ul class="nav-second-level">
                                    <li><a href="charts_flot.html">My Teachers</a></li>
                                    <li><a href="charts_Js.html">My Students</a></li>
                                    <li><a href="charts_morris.html">Parents</a></li>
                                    <li><a href="charts_sparkline.html">Administrators</a></li>
                                </ul>
                            </li>
                            <li><a href="chat.html"><i class="typcn typcn-messages mr-2"></i> Chat</a></li>
                            <li>
                                <a class="has-arrow material-ripple" href="#">
                                    <i class="typcn typcn-mail mr-2"></i>
                                    Mailbox
                                </a>
                                <ul class="nav-second-level">
                                    <li><a href="mailbox.html">Mailbox</a></li>
                                    <li><a href="mailbox_details.html">Mailbox Details</a></li>
                                    <li><a href="compose.html">Compose</a></li>
                                </ul>
                            </li>
                            <li>
                                <a class="has-arrow material-ripple" href="#">
                                    <i class="typcn typcn-archive mr-2"></i>
                                    Accademics
                                </a>
                                <ul class="nav-second-level">
                                    <li><a href="tables_bootstrap.html">Classes</a></li>
                                    <li>
                                        <a class="has-arrow" href="#" aria-expanded="false">E-learning</a>
                                        <ul class="nav-third-level">
                                            <li><a href="#">Question Bank</a></li>
                                            <li><a href="#">Learning Resources</a></li>
                                            <li><a href="#">Scheduled Tests</a></li>
                                            <li><a href="#">Scheduled Classes</a></li>
                                            <li><a href="#">Feedbacks</a></li>
                                            <li><a href="#">Results</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="#">Subjects</a></li>
                                    <li><a href="#">Grades</a></li>
                                    <li><a href="#">Behaviours &amp; Skills</a></li>
                                </ul>
                            </li>

                            <li class="nav-label">Components</li>
                            <li>
                                <a class="has-arrow material-ripple" href="#">
                                    <i class="typcn typcn-coffee mr-2"></i>
                                    Reports
                                </a>
                                <ul class="nav-second-level">
                                    <li><a href="#">Term Reports</a></li>
                                    <li><a href="#">Broad sheet</a></li>
                                    <li><a href="#">Generate Report</a></li>
                                    <li><a href="#">Generate PINs</a></li>
                                    <li><a href="#">Mid Term Report</a></li>
                                </ul>
                            </li>
                            <li>
                                <a class="has-arrow material-ripple" href="#">
                                    <i class="typcn typcn-clipboard mr-2"></i>
                                    Finance
                                </a>
                                <ul class="nav-second-level">
                                    <li><a href="forms_basic.html">Collectible Fees</a></li>
                                    <li><a href="forms_input_group.html">Invoice/Receipts </a></li>
                                    <li><a href="forms_mask.html">Payment History</a></li>
                                </ul>
                            </li>
                            <li><a href="calender.html"><i class="typcn typcn-calendar-outline mr-2"></i>Calendar</a></li>
                            <li class="nav-label">Extra</li>
                            <li>
                                <a class="has-arrow material-ripple" href="#">
                                    <i class="typcn typcn-device-tablet mr-2"></i>
                                    My School
                                </a>
                                <ul class="nav-second-level">
                                    <li><a href="#">School Profile</a></li>
                                    <li><a href="#">Portal Setting</a></li>
                                    <li><a href="#">Assign Subjects</a></li>
                                    <li><a href="#">Form Teachers</a></li>
                                </ul>
                            </li>
    
                            <li><a href="blank-page.html"><i class="typcn typcn-bookmark mr-2"></i>Annoucements</a></li>
                            <li>
                                <a class="has-arrow material-ripple" href="#">
                                    <i class="typcn typcn-puzzle-outline mr-2"></i>
                                    Layouts
                                </a>
                                <ul class="nav-second-level">
                                    <li><a href="layouts_layout.html">Layout</a></li>
                                    <li><a href="layouts_fixed.html">Fixed layout</a></li>
                                    <li><a href="layouts_fixed-without__navbar.html">Fixed layout without navbar</a></li>
                                </ul>
                            </li>
                            <li><a href="changelog.html"><i class="typcn typcn-attachment-outline mr-2"></i>Changelog<span class="badge badge-success ml-auto">v1.1.0</span></a></li>
                            <li><a href="#"><i class="typcn typcn-support mr-2"></i>Documentation</a></li>
                        </ul>
                    </nav>
                </div><!-- sidebar-body -->
                <div class="navbar-user d-none d-md-flex" id="sidebarUser">
                    <!-- Icon -->
                    <a href="#sidebarModalActivity" class="navbar-user-link" data-toggle="modal">
                        <span class="icon">
                            <i class="typcn typcn-bell"></i>
                        </span>
                    </a>
                    <!-- Icon -->
                    <a href="chat.html" class="navbar-user-link">
                        <span class="icon">
                            <i class="typcn typcn-messages"></i>
                        </span>
                    </a>
                    <!-- Icon -->
                    <a href="#modalSearch" class="navbar-user-link" data-toggle="modal">
                        <span class="icon">
                            <i class="typcn typcn-zoom-outline"></i>
                        </span>
                    </a>
                    <!-- settings -->
                    <div class="settings">
                        <!-- Toggle -->
                        <a href="#" id="sidebarIconCopy" class="navbar-user-link ropdown-toggle" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="icon">
                                <i class="typcn typcn-cog-outline"></i>
                            </span>
                        </a>
                        <!-- Menu -->
                        <div class="dropdown-menu" aria-labelledby="sidebarIconCopy">
                            <a href="#" class="dropdown-item"><i class="typcn typcn-user-outline fs-18"></i> My Profile</a>
                            <a href="user_profile.html" class="dropdown-item"><i class="typcn typcn-edit fs-18"></i> Edit Profile</a>
                            <a href="#" class="dropdown-item"><i class="typcn typcn-arrow-shuffle fs-18"></i> Activity Logs</a>
                            <a href="#" class="dropdown-item"><i class="typcn typcn-cog-outline fs-18"></i> Account Settings</a>
                            <a href="login.html" class="dropdown-item"><i class="typcn typcn-key-outline fs-18"></i> Sign Out</a>
                        </div>
                    </div>
                </div>
            </nav>