<footer class="footer-content">
                    <div class="footer-text d-flex align-items-center justify-content-between">
                        <div class="copy">© 2020 Buhulau School and Learning Management System</div>
                        <div class="credit">Designed by: <a href="#">i-Tech solutions</a></div>
                    </div>
                </footer><!--/.footer content-->